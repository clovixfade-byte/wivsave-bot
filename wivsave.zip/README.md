# @wivsave_bot — Instagram → MP4 bot

## Bot nima qiladi
- `/start` bosilganda: kanalga obuna bo'lishni so'raydi (majburiy obuna).
- "✅ Obuna bo'ldim" bosilganda: obunani tekshiradi, agar obuna bo'lsa — botning
  vazifasini tushuntiruvchi salomlashish xabarini yuboradi.
- Instagram havolasi yuborilsa: videoni yuklab, MP4 formatda qaytaradi.
- Instagram bo'lmagan havola yuborilsa: faqat Instagram havolalarini qabul
  qilishini aytadi.
- Oddiy so'z/matn yuborilsa: hech qanday javob bermaydi (ignor qiladi).

## 1-qadam: Bot yaratish (BotFather)
Siz buni allaqachon qilib bo'lgansiz (@wivsave_bot). BotFather'dan olgan
tokenni saqlab qo'ying — u `BOT_TOKEN` sifatida kerak bo'ladi.

## 2-qadam: Majburiy obuna kanalini sozlash
1. Telegram'da o'zingizning kanalingizni yarating (agar hali yo'q bo'lsa).
2. Botingizni ( @wivsave_bot ) kanalga **admin** qilib qo'shing (kamida
   "a'zolarni ko'rish" huquqi bilan) — aks holda bot obunani tekshira olmaydi.
3. `CHANNEL_USERNAME` ga kanal username'ini yozing, masalan: `@mening_kanalim`.
   Agar kanal yopiq (username'siz) bo'lsa, `CHANNEL_ID` ga kanalning raqamli
   ID'sini yozing (masalan: `-1001234567890`).

## 3-qadam: Lokal test qilish
```bash
pip install -r requirements.txt
export BOT_TOKEN="sizning_tokeningiz"
export CHANNEL_USERNAME="@mening_kanalim"
python bot.py
```

---

## Bepul 24/7 ishlaydigan hosting variantlari

### Variant A (eng ishonchli, chinakam bepul, doim yoniq): Oracle Cloud Free Tier
Oracle "Always Free" tarifida kichik virtual server (VM) beradi va u **hech
qachon o'chmaydi** — karta so'raladi, lekin pul yechilmaydi.

1. https://www.oracle.com/cloud/free/ saytida ro'yxatdan o'ting.
2. "Always Free" toifasidagi VM.Standard.E2.1.Micro (yoki Ampere ARM, yanada
   kuchliroq) instansini yarating (Ubuntu tanlang).
3. SSH orqali serverga kiring, so'ng:
   ```bash
   sudo apt update && sudo apt install -y python3-pip ffmpeg
   pip3 install -r requirements.txt
   ```
4. Botni doim ishlab turishi uchun `systemd` xizmati qiling:
   ```bash
   sudo nano /etc/systemd/system/wivsave.service
   ```
   Ichiga:
   ```
   [Unit]
   Description=Instagram to MP4 Telegram Bot
   After=network.target

   [Service]
   Environment=BOT_TOKEN=sizning_tokeningiz
   Environment=CHANNEL_USERNAME=@mening_kanalim
   WorkingDirectory=/home/ubuntu/bot
   ExecStart=/usr/bin/python3 bot.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```
   Keyin:
   ```bash
   sudo systemctl enable wivsave
   sudo systemctl start wivsave
   ```
   Shu bilan bot server qayta yoqilsa ham, xatolik bo'lib to'xtab qolsa ham
   avtomatik qayta ishga tushadi — 24/7.

### Variant B (osonroq, lekin cheklovli): Render.com Free Web Service
Render bepul tarifda "uxlab qolish" (inactivity'dan keyin to'xtash) muammosi
bor. Buni "UptimeRobot" (bepul) yordamida har 5 daqiqada ping yuborib oldini
olish mumkin, lekin bu 100% kafolat bermaydi. Oracle (Variant A) ancha
barqaror.

### Variant C: Railway / PythonAnywhere
Bular ham bor, lekin so'nggi paytlarda bepul tariflari juda cheklangan yoki
karta talab qiladi — shuning uchun tavsiya qilinmaydi.

---

## Eslatmalar
- `ffmpeg` o'rnatilgan bo'lishi kerak (video/audio birlashtirish uchun):
  `sudo apt install ffmpeg`
- Instagram ba'zi postlarni (private akkauntlar) yuklab bo'lmaydi — bu
  Instagram tomonidan cheklangan, kodga bog'liq emas.
- Tokenni hech qachon ochiq kodga (GitHub'ga) yozmang — `.env` yoki
  muhit o'zgaruvchisi orqali bering.
