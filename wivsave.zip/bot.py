import asyncio
import logging
import os
import re
import tempfile

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode, ChatMemberStatus
from aiogram.filters import CommandStart
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
)

import yt_dlp

logging.basicConfig(level=logging.INFO)

# ==========================
#   SOZLAMALAR (ENV orqali)
# ==========================
BOT_TOKEN = os.getenv("BOT_TOKEN", "8833712441:AAGyEqLkMh9LyAhWmykpFDyB-Lb_a3EWSWk")
# Majburiy obuna kanali. Masalan: "@mening_kanalim"
CHANNEL_USERNAME = os.getenv("CHANNEL_USERNAME", "@wivsave")
# get_chat_member funksiyasi uchun (odatda CHANNEL_USERNAME bilan bir xil bo'ladi,
# lekin agar kanal yopiq bo'lsa, kanalning raqamli ID sini shu yerga yozing: -100XXXXXXXXXX)
CHANNEL_ID = os.getenv("CHANNEL_ID", CHANNEL_USERNAME)

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

INSTAGRAM_RE = re.compile(r"(https?://)?(www\.)?(instagram\.com|instagr\.am)/\S+", re.IGNORECASE)
URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


def sub_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📢 Kanalga obuna bo'lish",
            url=f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}"
        )],
        [InlineKeyboardButton(text="✅ Obuna bo'ldim", callback_data="check_sub")],
    ])


async def is_subscribed(user_id: int) -> bool:
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=user_id)
        return member.status not in (ChatMemberStatus.LEFT, ChatMemberStatus.KICKED)
    except Exception as e:
        logging.warning(f"Obunani tekshirishda xatolik: {e}")
        return False


WELCOME_TEXT = (
    "👋 Salom!\n\n"
    "Men Instagramdan yuborilgan havola orqali videoni <b>MP4</b> formatga "
    "o'tkazib beruvchi botman.\n\n"
    "📎 Menga Instagram post yoki reels havolasini yuboring — men uni video "
    "fayl qilib qaytaraman.\n\n"
    "⚠️ Faqat Instagram havolalarini qabul qilaman."
)

FORCE_SUB_TEXT = (
    "🔒 Botdan foydalanish uchun avval quyidagi kanalga obuna bo'ling, "
    "so'ngra <b>«✅ Obuna bo'ldim»</b> tugmasini bosing."
)


@dp.message(CommandStart())
async def start_handler(message: Message):
    if await is_subscribed(message.from_user.id):
        await message.answer(WELCOME_TEXT)
    else:
        await message.answer(FORCE_SUB_TEXT, reply_markup=sub_keyboard())


@dp.callback_query(F.data == "check_sub")
async def check_sub_handler(callback: CallbackQuery):
    if await is_subscribed(callback.from_user.id):
        await callback.message.edit_text(WELCOME_TEXT)
        await callback.answer("✅ Tasdiqlandi!")
    else:
        await callback.answer("❌ Siz hali kanalga obuna bo'lmadingiz.", show_alert=True)


@dp.message(F.text)
async def message_handler(message: Message):
    text = message.text.strip()

    # Oddiy so'z/matn bo'lsa (havola bo'lmasa) — hech narsa qilmaymiz (ignor)
    if not URL_RE.search(text):
        return

    # Havola yuborilgan bo'lsa — avval majburiy obunani tekshiramiz
    if not await is_subscribed(message.from_user.id):
        await message.answer(FORCE_SUB_TEXT, reply_markup=sub_keyboard())
        return

    # Instagram havolasi bo'lmasa — ogohlantiramiz
    if not INSTAGRAM_RE.search(text):
        await message.answer("⚠️ Men faqat Instagram havolalaridan video yuklab bera olaman.")
        return

    await handle_instagram_link(message, text)


async def handle_instagram_link(message: Message, url: str):
    status_msg = await message.answer("⏳ Video yuklanmoqda, biroz kuting...")

    with tempfile.TemporaryDirectory() as tmp_dir:
        out_template = os.path.join(tmp_dir, "%(id)s.%(ext)s")
        ydl_opts = {
            "outtmpl": out_template,
            "format": "mp4/bestvideo+bestaudio/best",
            "merge_output_format": "mp4",
            "quiet": True,
            "noplaylist": True,
        }
        try:
            loop = asyncio.get_event_loop()

            def download():
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    return ydl.prepare_filename(info)

            filepath = await loop.run_in_executor(None, download)

            # Fayl kengaytmasi mp4 bo'lmasa, mp4 versiyasini qidiramiz
            if not filepath.endswith(".mp4"):
                base, _ = os.path.splitext(filepath)
                mp4_path = base + ".mp4"
                if os.path.exists(mp4_path):
                    filepath = mp4_path

            await message.answer_video(FSInputFile(filepath), caption="✅ Tayyor!")

        except Exception:
            logging.exception("Yuklashda xatolik")
            await message.answer(
                "❌ Videoni yuklab bo'lmadi.\n"
                "Havola noto'g'ri, post yopiq (private) yoki vaqtinchalik "
                "muammo bo'lishi mumkin."
            )
        finally:
            await status_msg.delete()


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
